package com.domain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D1aMsEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
