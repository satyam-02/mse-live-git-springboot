package com.domain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D1aMsEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(D1aMsEurekaServerApplication.class, args);
	}

}
